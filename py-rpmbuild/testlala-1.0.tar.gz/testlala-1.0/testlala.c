#include <stdio.h>

int main ()
{
	printf ("It is ok...\n");
	return 0;
}
